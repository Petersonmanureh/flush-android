# Flush 2.0 Product Notes

Flush is a nearby file sharing application for Android hosts and iPhone/Android browser clients.

## 2.0 changes

- Android can create a Local Only Hotspot automatically.
- Runtime Nearby Wi-Fi permission on Android 13+ with Android 12L-and-lower fallback permission.
- Detects a likely existing hotspot and offers to use it.
- Generates a standard Wi-Fi QR containing the temporary hotspot SSID/passkey.
- Shows a second QR for opening the local Flush transfer page.
- Send / Receive toggle on Android and on the browser interface.
- Multiple iPhones can connect at once and receive the same Android-selected files.
- Browser clients poll for new Android files and show a new-file signal automatically.
- iPhone photo/video selections stay visible as media tiles before sending.
- Per-file upload percentage overlays and an overall progress bar.
- Browser downloads from Android show per-file receive progress.
- Android shows live incoming/outgoing progress, direction, completion and notifications.
- Animated Android launch treatment.
- Incoming files remain saved to Downloads/Flush.

## Connection behavior

The preferred flow is:

1. Open Flush on Android.
2. Tap Turn On & Start Sharing.
3. Flush creates a temporary local-only Wi-Fi hotspot.
4. On iPhone or another Android, turn on Wi-Fi and scan the first QR to join the hotspot.
5. Scan the second QR to open Flush in the browser.
6. Toggle Send or Receive and transfer files with visible progress.

If Android cannot start the app-managed hotspot, Flush can use an existing Personal Hotspot instead.

## Important platform note

A browser cannot silently enable Wi-Fi or save arbitrary downloads without the receiving user's participation. Flush therefore provides explicit connection prompts, QR credentials, visible transfer state and browser save actions instead of trying to bypass Android/iOS platform controls.
