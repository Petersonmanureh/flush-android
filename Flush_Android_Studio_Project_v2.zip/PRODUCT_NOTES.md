# Flush v1 Product Notes

## Purpose
Make Android ↔ iPhone file transfer feel almost as simple as AirDrop without requiring an iPhone app.

## Core flow
- Android is the host.
- iPhone is the browser client.
- Android hotspot creates the private local network.
- Flush runs an embedded HTTP server on port 8080.
- QR contains the local URL plus a fresh PIN.

## Included in v1
- Native Android app; no Termux.
- Red branded interface.
- Start/stop sharing.
- Shortcut to hotspot settings.
- QR code connection.
- 6-digit session PIN.
- Multiple iPhone file uploads with progress.
- Files received into Downloads/Flush.
- Android system file picker for outgoing files.
- iPhone downloads through Safari.
- Foreground transfer service.
- No public server and no data charges for local transfers.

## Recommended v1.1
- Transfer history.
- Per-file Android receive notifications.
- Remove individual Android shared files from the session.
- Share-sheet integration: "Share with Flush".
- Better hotspot-IP discovery on unusual OEM Android builds.
- Optional custom port fallback when 8080 is occupied.
- Image/video thumbnails.
- Transfer speed + ETA.

## Future internet mode
A hosted mode can use a domain such as `flush.example.com` later. Recommended architecture:
- HTTPS API.
- Short-lived transfer rooms.
- End-to-end encryption before upload.
- WebSocket signalling.
- Direct WebRTC data channel when possible.
- Encrypted temporary relay storage only when peer-to-peer fails.
- Automatic expiry/deletion.

Do not make a public cloud relay the default for nearby hotspot transfers; local mode is faster, cheaper and more private.
