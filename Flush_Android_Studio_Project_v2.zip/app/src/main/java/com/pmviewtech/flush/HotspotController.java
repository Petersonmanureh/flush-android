package com.pmviewtech.flush;

import android.content.Context;
import android.net.wifi.SoftApConfiguration;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

public final class HotspotController {
    public interface Callback {
        void onStarted(String ssid, String passphrase);
        void onFailed(int reason);
        void onStopped();
    }

    private static WifiManager.LocalOnlyHotspotReservation reservation;
    private static boolean starting;
    private static String ssid;
    private static String passphrase;
    private static Callback callback;

    private HotspotController() {}

    public static synchronized boolean isActive() {
        return reservation != null && ssid != null;
    }

    public static synchronized boolean isStarting() {
        return starting;
    }

    public static synchronized String getSsid() {
        return ssid;
    }

    public static synchronized String getPassphrase() {
        return passphrase;
    }

    public static synchronized String getWifiQrPayload() {
        if (ssid == null) return null;
        if (passphrase == null || passphrase.isEmpty()) {
            return "WIFI:T:nopass;S:" + wifiEscape(ssid) + ";;";
        }
        return "WIFI:T:WPA;S:" + wifiEscape(ssid) + ";P:" + wifiEscape(passphrase) + ";;";
    }

    public static synchronized void start(Context context, Callback cb) {
        callback = cb;
        if (isActive()) {
            if (cb != null) cb.onStarted(ssid, passphrase);
            return;
        }
        if (starting) return;
        starting = true;

        WifiManager wifi = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifi == null) {
            starting = false;
            if (cb != null) cb.onFailed(WifiManager.LocalOnlyHotspotCallback.ERROR_GENERIC);
            return;
        }

        try {
            wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                @Override
                public void onStarted(WifiManager.LocalOnlyHotspotReservation res) {
                    String localSsid = null;
                    String localPass = null;
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            SoftApConfiguration config = res.getSoftApConfiguration();
                            localSsid = config.getSsid();
                            localPass = config.getPassphrase();
                        } else {
                            @SuppressWarnings("deprecation")
                            WifiConfiguration config = res.getWifiConfiguration();
                            if (config != null) {
                                localSsid = stripQuotes(config.SSID);
                                localPass = stripQuotes(config.preSharedKey);
                            }
                        }
                    } catch (Exception ignored) {}

                    synchronized (HotspotController.class) {
                        reservation = res;
                        starting = false;
                        ssid = localSsid == null || localSsid.trim().isEmpty() ? "Flush Hotspot" : localSsid;
                        passphrase = localPass;
                    }
                    Callback c = callback;
                    if (c != null) c.onStarted(ssid, passphrase);
                }

                @Override
                public void onStopped() {
                    synchronized (HotspotController.class) {
                        reservation = null;
                        starting = false;
                        ssid = null;
                        passphrase = null;
                    }
                    Callback c = callback;
                    if (c != null) c.onStopped();
                }

                @Override
                public void onFailed(int reason) {
                    synchronized (HotspotController.class) {
                        reservation = null;
                        starting = false;
                        ssid = null;
                        passphrase = null;
                    }
                    Callback c = callback;
                    if (c != null) c.onFailed(reason);
                }
            }, new Handler(Looper.getMainLooper()));
        } catch (SecurityException e) {
            starting = false;
            if (cb != null) cb.onFailed(WifiManager.LocalOnlyHotspotCallback.ERROR_GENERIC);
        } catch (Exception e) {
            starting = false;
            if (cb != null) cb.onFailed(WifiManager.LocalOnlyHotspotCallback.ERROR_GENERIC);
        }
    }

    public static synchronized void stop() {
        WifiManager.LocalOnlyHotspotReservation res = reservation;
        reservation = null;
        starting = false;
        ssid = null;
        passphrase = null;
        callback = null;
        if (res != null) {
            try { res.close(); } catch (Exception ignored) {}
        }
    }

    private static String stripQuotes(String value) {
        if (value == null) return null;
        String out = value.trim();
        if (out.length() >= 2 && out.startsWith("\"") && out.endsWith("\"")) {
            return out.substring(1, out.length() - 1);
        }
        return out;
    }

    private static String wifiEscape(String value) {
        if (value == null) return "";
        return value
                .replace("\\", "\\\\")
                .replace(";", "\\;")
                .replace(",", "\\,")
                .replace(":", "\\:")
                .replace("\"", "\\\"");
    }
}
