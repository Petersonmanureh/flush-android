package com.pmviewtech.flush;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class TransferTracker {
    public enum Direction { INCOMING, OUTGOING }
    public enum State { ACTIVE, COMPLETE, FAILED }

    public interface Listener { void onTransferChanged(); }

    public static final class Snapshot {
        public final String id;
        public final String name;
        public final String client;
        public final Direction direction;
        public final State state;
        public final long bytes;
        public final long total;
        public final long updatedAt;

        Snapshot(String id, String name, String client, Direction direction, State state,
                 long bytes, long total, long updatedAt) {
            this.id = id;
            this.name = name;
            this.client = client;
            this.direction = direction;
            this.state = state;
            this.bytes = bytes;
            this.total = total;
            this.updatedAt = updatedAt;
        }

        public int percent() {
            if (total <= 0) return -1;
            return (int)Math.max(0, Math.min(100, (bytes * 100L) / total));
        }
    }

    private static final class Item {
        String id;
        String name;
        String client;
        Direction direction;
        volatile State state;
        volatile long bytes;
        long total;
        volatile long updatedAt;
    }

    private static final Map<String, Item> ITEMS = new ConcurrentHashMap<>();
    private static final CopyOnWriteArrayList<Listener> LISTENERS = new CopyOnWriteArrayList<>();

    private TransferTracker() {}

    public static String start(String name, String client, Direction direction, long total) {
        Item item = new Item();
        item.id = direction.name() + "-" + System.nanoTime() + "-" + Math.abs((client == null ? "" : client).hashCode());
        item.name = name == null ? "file" : name;
        item.client = client == null ? "device" : client;
        item.direction = direction;
        item.state = State.ACTIVE;
        item.bytes = 0L;
        item.total = total;
        item.updatedAt = System.currentTimeMillis();
        ITEMS.put(item.id, item);
        prune();
        notifyListeners();
        return item.id;
    }

    public static void progress(String id, long bytes) {
        Item item = ITEMS.get(id);
        if (item == null) return;
        item.bytes = Math.max(item.bytes, bytes);
        item.updatedAt = System.currentTimeMillis();
        notifyListeners();
    }

    public static void complete(String id, long bytes) {
        Item item = ITEMS.get(id);
        if (item == null) return;
        item.bytes = Math.max(item.bytes, bytes);
        if (item.total > 0) item.bytes = item.total;
        item.state = State.COMPLETE;
        item.updatedAt = System.currentTimeMillis();
        prune();
        notifyListeners();
    }

    public static void fail(String id) {
        Item item = ITEMS.get(id);
        if (item == null) return;
        item.state = State.FAILED;
        item.updatedAt = System.currentTimeMillis();
        prune();
        notifyListeners();
    }

    public static List<Snapshot> snapshot() {
        List<Snapshot> out = new ArrayList<>();
        for (Item item : ITEMS.values()) {
            out.add(new Snapshot(item.id, item.name, item.client, item.direction, item.state,
                    item.bytes, item.total, item.updatedAt));
        }
        out.sort(Comparator.comparingLong((Snapshot s) -> s.updatedAt).reversed());
        return out;
    }

    public static Snapshot latestActive() {
        for (Snapshot s : snapshot()) if (s.state == State.ACTIVE) return s;
        return null;
    }

    public static Snapshot latest() {
        List<Snapshot> all = snapshot();
        return all.isEmpty() ? null : all.get(0);
    }

    public static void addListener(Listener listener) {
        if (listener != null && !LISTENERS.contains(listener)) LISTENERS.add(listener);
    }

    public static void removeListener(Listener listener) {
        LISTENERS.remove(listener);
    }

    private static void notifyListeners() {
        for (Listener listener : LISTENERS) {
            try { listener.onTransferChanged(); } catch (Exception ignored) {}
        }
    }

    private static void prune() {
        long cutoff = System.currentTimeMillis() - 10L * 60L * 1000L;
        List<String> remove = new ArrayList<>();
        for (Item item : ITEMS.values()) {
            if (item.state != State.ACTIVE && item.updatedAt < cutoff) remove.add(item.id);
        }
        for (String id : remove) ITEMS.remove(id);

        List<Snapshot> all = snapshotNoPrune();
        if (all.size() > 30) {
            Collections.sort(all, Comparator.comparingLong((Snapshot s) -> s.updatedAt));
            for (int i = 0; i < all.size() - 30; i++) ITEMS.remove(all.get(i).id);
        }
    }

    private static List<Snapshot> snapshotNoPrune() {
        List<Snapshot> out = new ArrayList<>();
        for (Item item : ITEMS.values()) {
            out.add(new Snapshot(item.id, item.name, item.client, item.direction, item.state,
                    item.bytes, item.total, item.updatedAt));
        }
        return out;
    }
}
