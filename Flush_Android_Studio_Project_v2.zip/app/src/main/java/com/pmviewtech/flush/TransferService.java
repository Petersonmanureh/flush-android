package com.pmviewtech.flush;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.security.SecureRandom;

public class TransferService extends Service {
    public static final String ACTION_START = "com.pmviewtech.flush.START";
    public static final String ACTION_STOP = "com.pmviewtech.flush.STOP";
    private static final String CHANNEL_ID = "flush_transfer";
    private static final int NOTIFICATION_ID = 4008;
    private static final int PORT = 8080;

    private static volatile LocalHttpServer server;
    private static volatile String sessionPin;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopServer();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification("Starting local sharing…"));
        startServerIfNeeded();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification("Flush is ready for nearby transfers"));
        return START_NOT_STICKY;
    }

    private synchronized void startServerIfNeeded() {
        if (server != null && server.isAlive()) return;
        sessionPin = String.format("%06d", RANDOM.nextInt(1_000_000));
        server = new LocalHttpServer(getApplicationContext(), PORT, sessionPin);
        server.start();
    }

    private synchronized void stopServer() {
        if (server != null) {
            server.shutdown();
            server = null;
        }
        sessionPin = null;
    }

    public static boolean isRunning() {
        LocalHttpServer s = server;
        return s != null && s.isAlive() && sessionPin != null;
    }

    public static String getSessionPin() {
        return sessionPin;
    }

    public static String getShareUrl() {
        if (!isRunning()) return null;
        String ip = LocalHttpServer.findBestLocalIp();
        if (ip == null) return null;
        return "http://" + ip + ":" + PORT + "/?pin=" + sessionPin;
    }

    public static int getPort() {
        return PORT;
    }

    @Override
    public void onDestroy() {
        stopServer();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
                this,
                0,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Flush")
                .setContentText(text)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "File transfers",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Keeps Flush available while a nearby transfer session is active.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
