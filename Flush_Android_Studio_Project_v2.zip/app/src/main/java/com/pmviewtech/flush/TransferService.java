package com.pmviewtech.flush;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.security.SecureRandom;

public class TransferService extends Service {
    public static final String ACTION_START = "com.pmviewtech.flush.START";
    public static final String ACTION_STOP = "com.pmviewtech.flush.STOP";
    private static final String CHANNEL_ID = "flush_transfer";
    private static final int NOTIFICATION_ID = 4008;
    private static final int PORT = 8080;

    private static volatile LocalHttpServer server;
    private static volatile String sessionPin;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final TransferTracker.Listener transferListener = this::refreshNotification;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        TransferTracker.addListener(transferListener);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopServer();
            HotspotController.stop();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification("Starting nearby sharing…", -1));
        startServerIfNeeded();
        refreshNotification();
        return START_NOT_STICKY;
    }

    private synchronized void startServerIfNeeded() {
        if (server != null && server.isAlive()) return;
        sessionPin = String.format("%06d", RANDOM.nextInt(1_000_000));
        server = new LocalHttpServer(getApplicationContext(), PORT, sessionPin);
        server.start();
    }

    private synchronized void stopServer() {
        if (server != null) {
            server.shutdown();
            server = null;
        }
        sessionPin = null;
    }

    public static boolean isRunning() {
        LocalHttpServer s = server;
        return s != null && s.isAlive() && sessionPin != null;
    }

    public static String getSessionPin() {
        return sessionPin;
    }

    public static String getShareUrl() {
        if (!isRunning()) return null;
        String ip = LocalHttpServer.findBestLocalIp();
        if (ip == null) return null;
        return "http://" + ip + ":" + PORT + "/?pin=" + sessionPin;
    }

    public static int getConnectedClientCount() {
        LocalHttpServer s = server;
        return s == null ? 0 : s.getConnectedClientCount();
    }

    public static int getPort() {
        return PORT;
    }

    @Override
    public void onDestroy() {
        TransferTracker.removeListener(transferListener);
        stopServer();
        HotspotController.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void refreshNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;

        TransferTracker.Snapshot active = TransferTracker.latestActive();
        if (active != null) {
            int pct = active.percent();
            String direction = active.direction == TransferTracker.Direction.INCOMING ? "Receiving" : "Sending";
            String text = direction + " " + active.name + (pct >= 0 ? " · " + pct + "%" : "");
            nm.notify(NOTIFICATION_ID, buildNotification(text, pct));
            return;
        }

        int clients = getConnectedClientCount();
        String text = clients > 0
                ? clients + (clients == 1 ? " device connected" : " devices connected")
                : "Flush is ready for nearby transfers";
        nm.notify(NOTIFICATION_ID, buildNotification(text, -1));
    }

    private Notification buildNotification(String text, int progress) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
                this,
                0,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Flush")
                .setContentText(text)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        if (progress >= 0) builder.setProgress(100, progress, false);
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "File transfers",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows Flush hotspot and nearby transfer progress.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
