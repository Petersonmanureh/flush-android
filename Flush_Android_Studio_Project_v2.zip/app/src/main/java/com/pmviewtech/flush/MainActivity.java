package com.pmviewtech.flush;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 1201;
    private static final int REQUEST_NOTIFICATIONS = 1202;
    private static final int REQUEST_NEARBY_WIFI = 1203;

    private static final int RED = Color.rgb(201, 20, 36);
    private static final int DEEP_RED = Color.rgb(145, 10, 23);
    private static final int TEXT = Color.rgb(24, 24, 27);
    private static final int MUTED = Color.rgb(112, 112, 120);
    private static final int BG = Color.rgb(247, 247, 249);
    private static final int GREEN = Color.rgb(22, 140, 78);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean existingHotspotMode = false;
    private boolean pendingStartAfterPermission = false;
    private boolean firstHotspotPromptShown = false;
    private String currentUrl;
    private String lastActiveTransferId;
    private String lastCompletedTransferId;

    private LinearLayout rootView;
    private LinearLayout heroView;
    private TextView brandMark;
    private TextView brandText;

    private TextView statusTitle;
    private TextView statusBody;
    private Button startButton;

    private LinearLayout shareCard;
    private LinearLayout wifiSection;
    private TextView wifiInstruction;
    private ImageView wifiQrView;
    private TextView ssidText;
    private TextView passwordText;
    private ImageView pageQrView;
    private TextView urlText;
    private TextView pinText;
    private TextView clientsText;

    private Button sendTab;
    private Button receiveTab;
    private LinearLayout sendCard;
    private LinearLayout receiveCard;
    private TextView selectedCount;
    private TextView broadcastInfo;
    private LinearLayout recentIncoming;
    private LinearLayout transferList;

    private final Runnable refreshLoop = new Runnable() {
        @Override
        public void run() {
            refreshUi();
            handler.postDelayed(this, 800);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        setContentView(buildUi());
        playIntroAnimation();
        refreshUi();
        handler.postDelayed(() -> {
            if (!firstHotspotPromptShown && !TransferService.isRunning()) {
                firstHotspotPromptShown = true;
                showHotspotPrompt();
            }
        }, 850);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshLoop);
        handler.post(refreshLoop);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(DEEP_RED);
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setPadding(dp(16), 0, dp(16), dp(36));
        scroll.addView(rootView, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        heroView = new LinearLayout(this);
        heroView.setOrientation(LinearLayout.VERTICAL);
        heroView.setPadding(dp(22), dp(30), dp(22), dp(30));
        GradientDrawable heroBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(224, 29, 51), DEEP_RED}
        );
        heroBg.setCornerRadii(new float[]{0,0,0,0,dp(30),dp(30),dp(30),dp(30)});
        heroView.setBackground(heroBg);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        heroParams.setMargins(-dp(16), 0, -dp(16), dp(18));
        rootView.addView(heroView, heroParams);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        heroView.addView(brandRow);

        brandMark = text("f.", 27, RED, true);
        brandMark.setGravity(Gravity.CENTER);
        brandMark.setBackground(rounded(Color.WHITE, 16));
        brandRow.addView(brandMark, new LinearLayout.LayoutParams(dp(52), dp(52)));

        brandText = text("flush.", 35, Color.WHITE, true);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brandLp.leftMargin = dp(12);
        brandRow.addView(brandText, brandLp);

        TextView heroCopy = text("Share photos, videos and files with iPhone or Android — visibly, privately and fast.", 16, Color.argb(238,255,255,255), false);
        heroCopy.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        copyLp.topMargin = dp(15);
        heroView.addView(heroCopy, copyLp);

        LinearLayout statusCard = card();
        rootView.addView(statusCard, cardParams());
        statusCard.addView(text("SHARING STATUS", 12, Color.rgb(139,139,148), true));
        statusTitle = text("Hotspot is off", 23, TEXT, true);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(6);
        statusCard.addView(statusTitle, stp);
        statusBody = text("Flush can create a private nearby hotspot for you.", 14, MUTED, false);
        statusBody.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sbp.topMargin = dp(6);
        statusCard.addView(statusBody, sbp);

        startButton = button("Turn On & Start Sharing", true);
        startButton.setOnClickListener(v -> toggleSharing());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bp.topMargin = dp(18);
        statusCard.addView(startButton, bp);

        Button existing = button("Use Existing Hotspot", false);
        existing.setOnClickListener(v -> startWithExistingHotspot());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        ep.topMargin = dp(9);
        statusCard.addView(existing, ep);

        Button settings = button("Hotspot Settings", false);
        settings.setOnClickListener(v -> openHotspotSettings());
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        hp.topMargin = dp(8);
        statusCard.addView(settings, hp);

        shareCard = card();
        rootView.addView(shareCard, cardParams());
        shareCard.addView(text("CONNECT DEVICES", 12, Color.rgb(139,139,148), true));
        TextView connectTitle = text("Join Flush", 22, TEXT, true);
        LinearLayout.LayoutParams ct = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ct.topMargin = dp(5);
        shareCard.addView(connectTitle, ct);
        clientsText = text("No devices connected yet", 13, MUTED, false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(5);
        shareCard.addView(clientsText, clp);

        wifiSection = new LinearLayout(this);
        wifiSection.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wsp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wsp.topMargin = dp(18);
        shareCard.addView(wifiSection, wsp);

        TextView step1 = text("1  CONNECT TO WI‑FI", 12, RED, true);
        wifiSection.addView(step1);
        wifiInstruction = text("On iPhone or Android, turn on Wi‑Fi and scan this code to join the temporary Flush hotspot.", 14, MUTED, false);
        wifiInstruction.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams wilp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wilp.topMargin = dp(6);
        wifiSection.addView(wifiInstruction, wilp);

        wifiQrView = new ImageView(this);
        wifiQrView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        wifiQrView.setBackground(rounded(Color.WHITE, 18));
        wifiQrView.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams wqlp = new LinearLayout.LayoutParams(dp(230), dp(230));
        wqlp.gravity = Gravity.CENTER_HORIZONTAL;
        wqlp.topMargin = dp(12);
        wifiSection.addView(wifiQrView, wqlp);

        LinearLayout wifiCredentials = new LinearLayout(this);
        wifiCredentials.setOrientation(LinearLayout.VERTICAL);
        wifiCredentials.setPadding(dp(14), dp(12), dp(14), dp(12));
        wifiCredentials.setBackground(rounded(Color.rgb(249, 246, 247), 14));
        ssidText = text("Network: —", 13, TEXT, true);
        passwordText = text("Password: —", 13, MUTED, false);
        wifiCredentials.addView(ssidText);
        LinearLayout.LayoutParams pwp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pwp.topMargin = dp(4);
        wifiCredentials.addView(passwordText, pwp);
        LinearLayout.LayoutParams wcp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wcp.topMargin = dp(10);
        wifiSection.addView(wifiCredentials, wcp);

        TextView step2 = text("2  OPEN FLUSH", 12, RED, true);
        LinearLayout.LayoutParams s2p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        s2p.topMargin = dp(22);
        shareCard.addView(step2, s2p);
        TextView pageInstruction = text("After the device is connected to Wi‑Fi, scan this second code to open the sharing page.", 14, MUTED, false);
        pageInstruction.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams pilp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pilp.topMargin = dp(6);
        shareCard.addView(pageInstruction, pilp);

        pageQrView = new ImageView(this);
        pageQrView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        pageQrView.setBackground(rounded(Color.WHITE, 18));
        pageQrView.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams pqlp = new LinearLayout.LayoutParams(dp(230), dp(230));
        pqlp.gravity = Gravity.CENTER_HORIZONTAL;
        pqlp.topMargin = dp(12);
        shareCard.addView(pageQrView, pqlp);

        LinearLayout pinBox = new LinearLayout(this);
        pinBox.setGravity(Gravity.CENTER_VERTICAL);
        pinBox.setPadding(dp(16), dp(12), dp(16), dp(12));
        pinBox.setBackground(rounded(TEXT, 15));
        pinBox.addView(text("Session PIN", 13, Color.rgb(185,185,192), false), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pinText = text("------", 23, Color.WHITE, true);
        pinText.setLetterSpacing(0.18f);
        pinBox.addView(pinText);
        LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pinLp.topMargin = dp(13);
        shareCard.addView(pinBox, pinLp);

        urlText = text("", 13, MUTED, false);
        urlText.setGravity(Gravity.CENTER);
        urlText.setTextIsSelectable(true);
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(10);
        shareCard.addView(urlText, urlLp);

        Button copy = button("Copy Open Link", false);
        copy.setOnClickListener(v -> copyCurrentUrl());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        cp.topMargin = dp(10);
        shareCard.addView(copy, cp);

        LinearLayout modeCard = card();
        modeCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        rootView.addView(modeCard, cardParams());
        LinearLayout segment = new LinearLayout(this);
        segment.setOrientation(LinearLayout.HORIZONTAL);
        segment.setPadding(dp(4), dp(4), dp(4), dp(4));
        segment.setBackground(rounded(Color.rgb(239,239,243), 15));
        modeCard.addView(segment);
        sendTab = segmentButton("Send", true);
        receiveTab = segmentButton("Receive", false);
        sendTab.setOnClickListener(v -> setMode(true));
        receiveTab.setOnClickListener(v -> setMode(false));
        segment.addView(sendTab, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams rtlp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        rtlp.leftMargin = dp(5);
        segment.addView(receiveTab, rtlp);

        sendCard = card();
        rootView.addView(sendCard, cardParams());
        sendCard.addView(text("SEND · ANDROID → CONNECTED DEVICES", 12, Color.rgb(139,139,148), true));
        TextView sendTitle = text("Share files with everyone connected", 21, TEXT, true);
        LinearLayout.LayoutParams stitle = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stitle.topMargin = dp(5);
        sendCard.addView(sendTitle, stitle);
        TextView sendDesc = text("Choose a file once. It will appear automatically on every connected iPhone or browser, and each device can receive the same file.", 14, MUTED, false);
        sendDesc.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams sdesc = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sdesc.topMargin = dp(5);
        sendCard.addView(sendDesc, sdesc);
        Button choose = button("Choose Android Files", true);
        choose.setOnClickListener(v -> pickFiles());
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        chooseLp.topMargin = dp(15);
        sendCard.addView(choose, chooseLp);
        selectedCount = text("0 files selected", 13, MUTED, false);
        selectedCount.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scp.topMargin = dp(10);
        sendCard.addView(selectedCount, scp);
        broadcastInfo = text("Waiting for a connected device", 13, MUTED, false);
        broadcastInfo.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams bip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bip.topMargin = dp(6);
        sendCard.addView(broadcastInfo, bip);
        Button clear = button("Clear Selected Files", false);
        clear.setOnClickListener(v -> { SharedFileStore.clear(); refreshUi(); });
        LinearLayout.LayoutParams clr = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        clr.topMargin = dp(11);
        sendCard.addView(clear, clr);

        receiveCard = card();
        rootView.addView(receiveCard, cardParams());
        receiveCard.setVisibility(View.GONE);
        receiveCard.addView(text("RECEIVE · CONNECTED DEVICES → ANDROID", 12, Color.rgb(139,139,148), true));
        TextView receiveTitle = text("Incoming files", 21, TEXT, true);
        LinearLayout.LayoutParams rtitle = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rtitle.topMargin = dp(5);
        receiveCard.addView(receiveTitle, rtitle);
        TextView receiveDesc = text("Files sent from iPhone are saved automatically to Downloads/Flush. Incoming progress is shown here and in the Android notification.", 14, MUTED, false);
        receiveDesc.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams rdesc = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rdesc.topMargin = dp(5);
        receiveCard.addView(receiveDesc, rdesc);
        recentIncoming = new LinearLayout(this);
        recentIncoming.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rilp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rilp.topMargin = dp(12);
        receiveCard.addView(recentIncoming, rilp);

        LinearLayout activityCard = card();
        rootView.addView(activityCard, cardParams());
        activityCard.addView(text("TRANSFER ACTIVITY", 12, Color.rgb(139,139,148), true));
        TextView at = text("Live transfer signal", 21, TEXT, true);
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        atp.topMargin = dp(5);
        activityCard.addView(at, atp);
        TextView ad = text("You will see when a file starts, its percentage, which direction it is moving and when it finishes.", 14, MUTED, false);
        LinearLayout.LayoutParams adp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        adp.topMargin = dp(4);
        activityCard.addView(ad, adp);
        transferList = new LinearLayout(this);
        transferList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(10);
        activityCard.addView(transferList, tlp);

        TextView footer = text("Flush 2.0 · Nearby sharing · No cloud required", 12, Color.rgb(145,145,152), false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.topMargin = dp(4);
        rootView.addView(footer, fp);

        shareCard.setVisibility(View.GONE);
        return scroll;
    }

    private void playIntroAnimation() {
        rootView.setAlpha(0f);
        rootView.setTranslationY(dp(18));
        rootView.animate().alpha(1f).translationY(0f).setDuration(480).start();

        brandMark.setScaleX(0.35f);
        brandMark.setScaleY(0.35f);
        brandMark.setRotation(-14f);
        brandMark.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(650).setInterpolator(new OvershootInterpolator(1.5f)).start();

        brandText.setAlpha(0f);
        brandText.setTranslationX(-dp(14));
        brandText.animate().alpha(1f).translationX(0f).setStartDelay(130).setDuration(430).start();
    }

    private void showHotspotPrompt() {
        boolean existingDetected = LocalHttpServer.hasLikelyHotspotInterface();
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(existingDetected ? "Hotspot detected" : "Hotspot is off")
                .setMessage(existingDetected
                        ? "Flush can use the hotspot already running on this phone, or create its own temporary nearby hotspot with a scannable Wi‑Fi passkey."
                        : "Flush needs a nearby Wi‑Fi network. It can create a private temporary hotspot automatically. On the other phone, turn on Wi‑Fi and scan the connection code.")
                .setNegativeButton("Not now", null);
        if (existingDetected) {
            builder.setPositiveButton("Use Existing Hotspot", (d, w) -> startWithExistingHotspot())
                    .setNeutralButton("Create Flush Hotspot", (d, w) -> beginManagedSharing());
        } else {
            builder.setPositiveButton("Turn On & Share", (d, w) -> beginManagedSharing());
        }
        builder.show();
    }

    private void toggleSharing() {
        if (TransferService.isRunning()) {
            Intent stop = new Intent(this, TransferService.class);
            stop.setAction(TransferService.ACTION_STOP);
            startService(stop);
            HotspotController.stop();
            existingHotspotMode = false;
            handler.postDelayed(this::refreshUi, 300);
            return;
        }
        beginManagedSharing();
    }

    private void beginManagedSharing() {
        if (!hasWifiPermission()) {
            pendingStartAfterPermission = true;
            requestWifiPermission();
            return;
        }
        existingHotspotMode = false;
        statusTitle.setText("Starting hotspot…");
        statusTitle.setTextColor(RED);
        statusBody.setText("Creating a private Flush Wi‑Fi network.");
        startButton.setEnabled(false);

        HotspotController.start(this, new HotspotController.Callback() {
            @Override
            public void onStarted(String ssid, String passphrase) {
                runOnUiThread(() -> {
                    startTransferService();
                    startButton.setEnabled(true);
                    handler.postDelayed(MainActivity.this::refreshUi, 450);
                    handler.postDelayed(MainActivity.this::refreshUi, 1100);
                });
            }

            @Override
            public void onFailed(int reason) {
                runOnUiThread(() -> {
                    startButton.setEnabled(true);
                    showHotspotFailure(reason);
                });
            }

            @Override
            public void onStopped() {
                runOnUiThread(() -> {
                    if (TransferService.isRunning() && !existingHotspotMode) {
                        Intent stop = new Intent(MainActivity.this, TransferService.class);
                        stop.setAction(TransferService.ACTION_STOP);
                        startService(stop);
                    }
                    refreshUi();
                });
            }
        });
    }

    private void showHotspotFailure(int reason) {
        String extra = reason == WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE
                ? " Your normal Personal Hotspot may already be active."
                : "";
        new AlertDialog.Builder(this)
                .setTitle("Couldn’t start Flush hotspot")
                .setMessage("Android did not allow Flush to create its temporary hotspot." + extra + " You can use your existing hotspot instead.")
                .setPositiveButton("Use Existing Hotspot", (d, w) -> startWithExistingHotspot())
                .setNeutralButton("Hotspot Settings", (d, w) -> openHotspotSettings())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startWithExistingHotspot() {
        existingHotspotMode = true;
        HotspotController.stop();
        startTransferService();
        handler.postDelayed(this::refreshUi, 500);
        handler.postDelayed(() -> {
            if (TransferService.getShareUrl() == null) {
                new AlertDialog.Builder(this)
                        .setTitle("Turn on your hotspot")
                        .setMessage("Flush cannot see a hotspot address yet. Turn on Personal Hotspot, then return to Flush.")
                        .setPositiveButton("Open Hotspot Settings", (d, w) -> openHotspotSettings())
                        .setNegativeButton("I’ll do it", null)
                        .show();
            }
        }, 1200);
    }

    private void startTransferService() {
        ensureNotificationPermission();
        Intent start = new Intent(this, TransferService.class);
        start.setAction(TransferService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(start);
        else startService(start);
    }

    private boolean hasWifiPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestWifiPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, REQUEST_NEARBY_WIFI);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_NEARBY_WIFI);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NEARBY_WIFI) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && pendingStartAfterPermission) {
                pendingStartAfterPermission = false;
                beginManagedSharing();
            } else if (!granted) {
                pendingStartAfterPermission = false;
                new AlertDialog.Builder(this)
                        .setTitle("Nearby Wi‑Fi permission needed")
                        .setMessage("Flush needs Nearby Wi‑Fi permission to create the temporary local hotspot. You can still use your normal hotspot instead.")
                        .setPositiveButton("Use Existing Hotspot", (d, w) -> startWithExistingHotspot())
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        }
    }

    private void openHotspotSettings() {
        try {
            startActivity(new Intent("android.settings.TETHER_SETTINGS"));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void pickFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;

        int added = 0;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) {
                    persistReadPermission(uri, data.getFlags());
                    SharedFileStore.add(this, uri);
                    added++;
                }
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            persistReadPermission(uri, data.getFlags());
            SharedFileStore.add(this, uri);
            added++;
        }
        if (added > 0) {
            Toast.makeText(this, added + (added == 1 ? " file is ready on all connected devices" : " files are ready on all connected devices"), Toast.LENGTH_SHORT).show();
        }
        refreshUi();
    }

    private void persistReadPermission(Uri uri, int flags) {
        int takeFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (Exception ignored) {}
    }

    private void setMode(boolean send) {
        sendCard.setVisibility(send ? View.VISIBLE : View.GONE);
        receiveCard.setVisibility(send ? View.GONE : View.VISIBLE);
        styleSegmentButton(sendTab, send);
        styleSegmentButton(receiveTab, !send);
        refreshTransferViews();
    }

    private void refreshUi() {
        boolean running = TransferService.isRunning();
        int count = SharedFileStore.count();
        int clients = TransferService.getConnectedClientCount();
        selectedCount.setText(count + (count == 1 ? " file selected" : " files selected"));
        broadcastInfo.setText(clients > 0
                ? "Available to " + clients + (clients == 1 ? " connected device" : " connected devices")
                : "Waiting for a connected device");
        clientsText.setText(clients == 0
                ? "No devices connected yet"
                : clients + (clients == 1 ? " device connected" : " devices connected"));

        refreshTransferViews();
        showTransferSignals();

        if (!running) {
            boolean existingDetected = LocalHttpServer.hasLikelyHotspotInterface();
            statusTitle.setText(HotspotController.isStarting() ? "Starting hotspot…" : (existingDetected ? "Hotspot detected" : "Hotspot is off"));
            statusTitle.setTextColor(HotspotController.isStarting() ? RED : (existingDetected ? GREEN : TEXT));
            statusBody.setText(HotspotController.isStarting()
                    ? "Creating a private Flush Wi‑Fi network."
                    : (existingDetected
                        ? "A hotspot appears to be active. Tap Use Existing Hotspot, or let Flush create its own temporary network."
                        : "Tap Turn On & Start Sharing. Flush will create a temporary hotspot and show a Wi‑Fi QR code."));
            startButton.setText(HotspotController.isStarting() ? "Starting…" : "Turn On & Start Sharing");
            startButton.setEnabled(!HotspotController.isStarting());
            shareCard.setVisibility(View.GONE);
            currentUrl = null;
            return;
        }

        startButton.setEnabled(true);
        startButton.setText("Stop Sharing");
        shareCard.setVisibility(View.VISIBLE);
        currentUrl = TransferService.getShareUrl();
        String pin = TransferService.getSessionPin();
        pinText.setText(pin == null ? "------" : pin);

        if (HotspotController.isActive() && !existingHotspotMode) {
            wifiSection.setVisibility(View.VISIBLE);
            wifiInstruction.setText("On iPhone or Android, turn on Wi‑Fi and scan this code. It contains the Flush hotspot name and passkey, so supported camera apps can offer to connect automatically.");
            String ssid = HotspotController.getSsid();
            String pass = HotspotController.getPassphrase();
            ssidText.setText("Network: " + (ssid == null ? "Flush" : ssid));
            passwordText.setText("Password: " + ((pass == null || pass.isEmpty()) ? "No password" : pass));
            String wifiQr = HotspotController.getWifiQrPayload();
            wifiQrView.setImageBitmap(wifiQr == null ? null : makeQr(wifiQr, 720));
        } else {
            wifiSection.setVisibility(View.VISIBLE);
            wifiInstruction.setText("Use your phone’s existing hotspot name and password. Turn on Wi‑Fi on the iPhone, connect to that hotspot, then scan the Open Flush code below.");
            wifiQrView.setImageDrawable(null);
            ssidText.setText("Network: your existing hotspot");
            passwordText.setText("Password: use the passkey shown in Android Hotspot Settings");
        }

        if (currentUrl == null) {
            statusTitle.setText("Waiting for hotspot address");
            statusTitle.setTextColor(RED);
            statusBody.setText("The hotspot is starting, but its local address is not ready yet.");
            urlText.setText("Preparing local link…");
            pageQrView.setImageDrawable(null);
            return;
        }

        statusTitle.setText(clients > 0 ? "Connected & ready" : "Ready to connect");
        statusTitle.setTextColor(GREEN);
        statusBody.setText(clients > 0
                ? clients + (clients == 1 ? " device is connected. Transfers will show live progress." : " devices are connected. The same Android file can be received by all of them.")
                : "On the other phone, turn on Wi‑Fi, join the Flush hotspot, then open the transfer page.");
        urlText.setText(currentUrl);
        pageQrView.setImageBitmap(makeQr(currentUrl, 720));
    }

    private void showTransferSignals() {
        TransferTracker.Snapshot active = TransferTracker.latestActive();
        if (active != null && !active.id.equals(lastActiveTransferId)) {
            lastActiveTransferId = active.id;
            String verb = active.direction == TransferTracker.Direction.INCOMING ? "Receiving " : "Sending ";
            Toast.makeText(this, verb + active.name, Toast.LENGTH_SHORT).show();
        }
        TransferTracker.Snapshot latest = TransferTracker.latest();
        if (latest != null && latest.state == TransferTracker.State.COMPLETE && !latest.id.equals(lastCompletedTransferId)) {
            lastCompletedTransferId = latest.id;
            String verb = latest.direction == TransferTracker.Direction.INCOMING ? "Received " : "Sent ";
            Toast.makeText(this, verb + latest.name + " ✓", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshTransferViews() {
        List<TransferTracker.Snapshot> transfers = TransferTracker.snapshot();
        transferList.removeAllViews();
        recentIncoming.removeAllViews();

        int shown = 0;
        int incomingShown = 0;
        for (TransferTracker.Snapshot snapshot : transfers) {
            if (shown < 6) {
                transferList.addView(transferRow(snapshot));
                shown++;
            }
            if (snapshot.direction == TransferTracker.Direction.INCOMING && incomingShown < 5) {
                recentIncoming.addView(transferRow(snapshot));
                incomingShown++;
            }
        }
        if (shown == 0) transferList.addView(emptyLine("No transfers yet."));
        if (incomingShown == 0) recentIncoming.addView(emptyLine("Waiting for an iPhone to send files…"));
    }

    private View transferRow(TransferTracker.Snapshot snapshot) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(10), 0, dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        wrap.addView(top);

        String arrow = snapshot.direction == TransferTracker.Direction.INCOMING ? "↓" : "↑";
        TextView icon = text(arrow, 23, snapshot.direction == TransferTracker.Direction.INCOMING ? GREEN : RED, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(Color.rgb(249,246,247), 12));
        top.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout meta = new LinearLayout(this);
        meta.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mp.leftMargin = dp(11);
        top.addView(meta, mp);
        TextView name = text(snapshot.name, 14, TEXT, true);
        name.setSingleLine(true);
        meta.addView(name);

        int pct = snapshot.percent();
        String state;
        if (snapshot.state == TransferTracker.State.ACTIVE) state = pct >= 0 ? pct + "% · " + humanSize(snapshot.bytes) : humanSize(snapshot.bytes);
        else if (snapshot.state == TransferTracker.State.COMPLETE) state = "Complete ✓ · " + humanSize(snapshot.bytes);
        else state = "Transfer failed";
        TextView detail = text(state, 12, snapshot.state == TransferTracker.State.FAILED ? RED : MUTED, false);
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailLp.topMargin = dp(3);
        meta.addView(detail, detailLp);

        if (snapshot.state == TransferTracker.State.ACTIVE) {
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setMax(100);
            if (pct >= 0) {
                progress.setIndeterminate(false);
                progress.setProgress(pct);
            } else {
                progress.setIndeterminate(true);
            }
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5));
            pp.topMargin = dp(8);
            wrap.addView(progress, pp);
        }
        return wrap;
    }

    private TextView emptyLine(String value) {
        TextView v = text(value, 13, MUTED, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(15), 0, dp(15));
        return v;
    }

    private Bitmap makeQr(String value, int size) {
        try {
            BitMatrix matrix = new QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, size, size);
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            int dark = Color.rgb(24,24,27);
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? dark : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException e) {
            return null;
        }
    }

    private void copyCurrentUrl() {
        if (currentUrl == null) {
            Toast.makeText(this, "The local link is not ready yet", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Flush link", currentUrl));
            Toast.makeText(this, "Flush link copied", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(rounded(Color.WHITE, 22));
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(14);
        return lp;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String label, boolean filled) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(14), 0, dp(14), 0);
        if (filled) {
            b.setTextColor(Color.WHITE);
            b.setBackground(rounded(RED, 14));
        } else {
            b.setTextColor(RED);
            GradientDrawable bg = rounded(Color.rgb(255, 245, 247), 14);
            bg.setStroke(dp(1), Color.rgb(241, 190, 198));
            b.setBackground(bg);
        }
        return b;
    }

    private Button segmentButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        styleSegmentButton(b, active);
        return b;
    }

    private void styleSegmentButton(Button b, boolean active) {
        b.setTextColor(active ? RED : MUTED);
        b.setBackground(rounded(active ? Color.WHITE : Color.TRANSPARENT, 12));
        b.setElevation(active ? dp(1) : 0);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private String humanSize(long n) {
        if (n < 0) return "size unavailable";
        double value = n;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int i = 0;
        while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
        if (i == 0) return ((long)value) + " " + units[i];
        return String.format(Locale.US, "%.1f %s", value, units[i]);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
