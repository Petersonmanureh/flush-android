package com.pmviewtech.flush;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 1201;
    private static final int REQUEST_NOTIFICATIONS = 1202;

    private static final int RED = Color.rgb(201, 20, 36);
    private static final int DEEP_RED = Color.rgb(145, 10, 23);
    private static final int TEXT = Color.rgb(24, 24, 27);
    private static final int MUTED = Color.rgb(112, 112, 120);
    private static final int BG = Color.rgb(247, 247, 249);

    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView statusTitle;
    private TextView statusBody;
    private TextView urlText;
    private TextView pinText;
    private TextView selectedCount;
    private ImageView qrView;
    private Button startButton;
    private LinearLayout shareCard;
    private String currentUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        setContentView(buildUi());
        refreshUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(this::refreshUi, 350);
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(DEEP_RED);
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), 0, dp(16), dp(36));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(32), dp(22), dp(30));
        GradientDrawable heroBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(220, 27, 48), DEEP_RED}
        );
        heroBg.setCornerRadii(new float[]{0,0,0,0,dp(28),dp(28),dp(28),dp(28)});
        hero.setBackground(heroBg);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        heroParams.setMargins(-dp(16), 0, -dp(16), dp(18));
        root.addView(hero, heroParams);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(brandRow);

        TextView mark = text("F", 25, Color.rgb(185, 15, 31), true);
        mark.setGravity(Gravity.CENTER);
        GradientDrawable markBg = rounded(Color.WHITE, 16);
        mark.setBackground(markBg);
        brandRow.addView(mark, new LinearLayout.LayoutParams(dp(50), dp(50)));

        TextView brand = text("flush.", 34, Color.WHITE, true);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brandLp.leftMargin = dp(12);
        brandRow.addView(brand, brandLp);

        TextView heroCopy = text("Move files between Android and iPhone in seconds — privately, through your hotspot.", 16, Color.argb(235,255,255,255), false);
        heroCopy.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        copyLp.topMargin = dp(15);
        hero.addView(heroCopy, copyLp);

        LinearLayout statusCard = card();
        root.addView(statusCard, cardParams());
        TextView kicker = text("SHARING STATUS", 12, Color.rgb(139,139,148), true);
        statusCard.addView(kicker);
        statusTitle = text("Not sharing", 23, TEXT, true);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(6);
        statusCard.addView(statusTitle, stp);
        statusBody = text("Turn on your Android hotspot, then start Flush.", 14, MUTED, false);
        statusBody.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sbp.topMargin = dp(6);
        statusCard.addView(statusBody, sbp);

        startButton = button("Start Sharing", true);
        startButton.setOnClickListener(v -> toggleSharing());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bp.topMargin = dp(18);
        statusCard.addView(startButton, bp);

        Button hotspot = button("Open Hotspot Settings", false);
        hotspot.setOnClickListener(v -> openHotspotSettings());
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        hp.topMargin = dp(9);
        statusCard.addView(hotspot, hp);

        shareCard = card();
        root.addView(shareCard, cardParams());
        TextView scanKicker = text("CONNECT IPHONE", 12, Color.rgb(139,139,148), true);
        shareCard.addView(scanKicker);
        TextView scanTitle = text("Scan and open", 22, TEXT, true);
        LinearLayout.LayoutParams scanTitleLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scanTitleLp.topMargin = dp(5);
        shareCard.addView(scanTitle, scanTitleLp);

        TextView scanBody = text("Connect the iPhone to this Android hotspot, then scan the QR code with the iPhone camera.", 14, MUTED, false);
        scanBody.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams scanBodyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scanBodyLp.topMargin = dp(5);
        shareCard.addView(scanBody, scanBodyLp);

        qrView = new ImageView(this);
        qrView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        qrView.setBackground(rounded(Color.WHITE, 18));
        qrView.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(dp(240), dp(240));
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        qlp.topMargin = dp(17);
        shareCard.addView(qrView, qlp);

        LinearLayout pinBox = new LinearLayout(this);
        pinBox.setGravity(Gravity.CENTER_VERTICAL);
        pinBox.setPadding(dp(16), dp(12), dp(16), dp(12));
        pinBox.setBackground(rounded(TEXT, 15));
        TextView pinLabel = text("Session PIN", 13, Color.rgb(185,185,192), false);
        pinBox.addView(pinLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pinText = text("------", 23, Color.WHITE, true);
        pinText.setLetterSpacing(0.18f);
        pinBox.addView(pinText);
        LinearLayout.LayoutParams pinLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pinLp.topMargin = dp(15);
        shareCard.addView(pinBox, pinLp);

        urlText = text("", 13, MUTED, false);
        urlText.setGravity(Gravity.CENTER);
        urlText.setTextIsSelectable(true);
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(12);
        shareCard.addView(urlText, urlLp);

        Button copy = button("Copy Link", false);
        copy.setOnClickListener(v -> copyCurrentUrl());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        cp.topMargin = dp(12);
        shareCard.addView(copy, cp);

        LinearLayout filesCard = card();
        root.addView(filesCard, cardParams());
        TextView fk = text("ANDROID → IPHONE", 12, Color.rgb(139,139,148), true);
        filesCard.addView(fk);
        TextView ft = text("Choose files to share", 21, TEXT, true);
        LinearLayout.LayoutParams ftp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ftp.topMargin = dp(5);
        filesCard.addView(ft, ftp);
        TextView fd = text("Only files you select here will appear on the iPhone transfer page.", 14, MUTED, false);
        LinearLayout.LayoutParams fdp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fdp.topMargin = dp(5);
        filesCard.addView(fd, fdp);

        Button choose = button("Choose Android Files", true);
        choose.setOnClickListener(v -> pickFiles());
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        chooseLp.topMargin = dp(15);
        filesCard.addView(choose, chooseLp);

        selectedCount = text("0 files selected", 13, MUTED, false);
        selectedCount.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scp.topMargin = dp(10);
        filesCard.addView(selectedCount, scp);

        TextView receive = text("iPhone → Android files are automatically saved in Downloads/Flush.", 13, MUTED, false);
        receive.setGravity(Gravity.CENTER_HORIZONTAL);
        receive.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(16);
        filesCard.addView(receive, rp);

        TextView footer = text("Flush 1.0 · Nearby transfer mode · No cloud required", 12, Color.rgb(145,145,152), false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.topMargin = dp(5);
        root.addView(footer, fp);

        return scroll;
    }

    private void toggleSharing() {
        if (TransferService.isRunning()) {
            Intent stop = new Intent(this, TransferService.class);
            stop.setAction(TransferService.ACTION_STOP);
            startService(stop);
            handler.postDelayed(this::refreshUi, 250);
            return;
        }

        ensureNotificationPermission();
        Intent start = new Intent(this, TransferService.class);
        start.setAction(TransferService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(start);
        else startService(start);
        handler.postDelayed(this::refreshUi, 450);
        handler.postDelayed(this::refreshUi, 1200);
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void openHotspotSettings() {
        try {
            startActivity(new Intent("android.settings.TETHER_SETTINGS"));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void pickFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;

        int added = 0;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) {
                    persistReadPermission(uri, data.getFlags());
                    SharedFileStore.add(this, uri);
                    added++;
                }
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            persistReadPermission(uri, data.getFlags());
            SharedFileStore.add(this, uri);
            added++;
        }
        if (added > 0) Toast.makeText(this, added + (added == 1 ? " file ready to share" : " files ready to share"), Toast.LENGTH_SHORT).show();
        refreshUi();
    }

    private void persistReadPermission(Uri uri, int flags) {
        int takeFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (Exception ignored) {}
    }

    private void refreshUi() {
        boolean running = TransferService.isRunning();
        int count = SharedFileStore.count();
        selectedCount.setText(count + (count == 1 ? " file selected" : " files selected"));

        if (!running) {
            statusTitle.setText("Not sharing");
            statusTitle.setTextColor(TEXT);
            statusBody.setText("Turn on your Android hotspot, then tap Start Sharing.");
            startButton.setText("Start Sharing");
            shareCard.setVisibility(View.GONE);
            currentUrl = null;
            return;
        }

        startButton.setText("Stop Sharing");
        currentUrl = TransferService.getShareUrl();
        String pin = TransferService.getSessionPin();
        pinText.setText(pin == null ? "------" : pin);
        shareCard.setVisibility(View.VISIBLE);

        if (currentUrl == null) {
            statusTitle.setText("Waiting for hotspot");
            statusTitle.setTextColor(RED);
            statusBody.setText("Flush is running, but no hotspot/Wi-Fi address is available yet. Turn on hotspot, then return here.");
            urlText.setText("Turn on hotspot to generate the iPhone link.");
            qrView.setImageDrawable(null);
            return;
        }

        statusTitle.setText("Ready to transfer");
        statusTitle.setTextColor(Color.rgb(22, 122, 71));
        statusBody.setText("Connect the iPhone to this Android hotspot and scan the QR code below.");
        urlText.setText(currentUrl);
        qrView.setImageBitmap(makeQr(currentUrl, 720));
    }

    private Bitmap makeQr(String text, int size) {
        try {
            BitMatrix matrix = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size);
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            int dark = Color.rgb(24,24,27);
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? dark : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException e) {
            return null;
        }
    }

    private void copyCurrentUrl() {
        if (currentUrl == null) {
            Toast.makeText(this, "Turn on hotspot first", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Flush link", currentUrl));
            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(rounded(Color.WHITE, 22));
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(14);
        return lp;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String label, boolean filled) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(14), 0, dp(14), 0);
        if (filled) {
            b.setTextColor(Color.WHITE);
            b.setBackground(rounded(RED, 14));
        } else {
            b.setTextColor(RED);
            GradientDrawable bg = rounded(Color.rgb(255, 245, 247), 14);
            bg.setStroke(dp(1), Color.rgb(241, 190, 198));
            b.setBackground(bg);
        }
        return b;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
