package com.pmviewtech.flush;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 1201;
    private static final int REQUEST_NOTIFICATIONS = 1202;
    private static final int REQUEST_NEARBY_WIFI = 1203;

    private static final int RED = Color.rgb(201, 20, 36);
    private static final int DEEP_RED = Color.rgb(145, 10, 23);
    private static final int TEXT = Color.rgb(24, 24, 27);
    private static final int MUTED = Color.rgb(112, 112, 120);
    private static final int BG = Color.rgb(247, 247, 249);
    private static final int GREEN = Color.rgb(22, 140, 78);

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean existingHotspotMode = false;
    private boolean pendingStartAfterPermission = false;
    private boolean firstHotspotPromptShown = false;
    private boolean sendMode = true;
    private String currentUrl;
    private String lastActiveTransferId;
    private String lastCompletedTransferId;

    private LinearLayout rootView;
    private TextView brandMark;
    private TextView brandText;

    private TextView statusTitle;
    private TextView statusBody;
    private TextView clientsText;
    private Button startButton;
    private Button connectButton;
    private Button detailsButton;

    private Button sendTab;
    private Button receiveTab;
    private LinearLayout sendCard;
    private LinearLayout receiveCard;
    private TextView selectedCount;
    private TextView broadcastInfo;
    private LinearLayout recentIncoming;

    private LinearLayout activityCard;
    private LinearLayout transferList;

    private final Runnable refreshLoop = new Runnable() {
        @Override
        public void run() {
            refreshUi();
            handler.postDelayed(this, 800);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        setContentView(buildUi());
        playIntroAnimation();
        refreshUi();
        handler.postDelayed(() -> {
            if (!firstHotspotPromptShown && !TransferService.isRunning()) {
                firstHotspotPromptShown = true;
                showHotspotPrompt();
            }
        }, 850);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshLoop);
        handler.post(refreshLoop);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(DEEP_RED);
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setPadding(dp(16), 0, dp(16), dp(34));
        scroll.addView(rootView, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        buildCompactHero();
        buildStatusCard();
        buildModeSwitch();
        buildSendCard();
        buildReceiveCard();
        buildActivityCard();

        TextView footer = text("Flush · Nearby sharing · No cloud required", 12, Color.rgb(145,145,152), false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.topMargin = dp(2);
        rootView.addView(footer, fp);

        return scroll;
    }

    private void buildCompactHero() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(24), dp(22), dp(24));
        GradientDrawable heroBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(224, 29, 51), DEEP_RED}
        );
        heroBg.setCornerRadii(new float[]{0,0,0,0,dp(28),dp(28),dp(28),dp(28)});
        hero.setBackground(heroBg);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        heroParams.setMargins(-dp(16), 0, -dp(16), dp(14));
        rootView.addView(hero, heroParams);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(brandRow);

        brandMark = text("f.", 25, RED, true);
        brandMark.setGravity(Gravity.CENTER);
        brandMark.setBackground(rounded(Color.WHITE, 15));
        brandRow.addView(brandMark, new LinearLayout.LayoutParams(dp(48), dp(48)));

        brandText = text("flush.", 33, Color.WHITE, true);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brandLp.leftMargin = dp(12);
        brandRow.addView(brandText, brandLp);

        TextView heroCopy = text("Nearby sharing, without the clutter.", 15, Color.argb(235,255,255,255), false);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        copyLp.topMargin = dp(10);
        hero.addView(heroCopy, copyLp);
    }

    private void buildStatusCard() {
        LinearLayout card = card();
        rootView.addView(card, cardParams());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(top);

        LinearLayout meta = new LinearLayout(this);
        meta.setOrientation(LinearLayout.VERTICAL);
        top.addView(meta, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        statusTitle = text("Hotspot is off", 22, TEXT, true);
        meta.addView(statusTitle);

        clientsText = text("Not connected", 13, MUTED, false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(3);
        meta.addView(clientsText, clp);

        TextView dot = text("●", 22, Color.rgb(190,190,196), true);
        dot.setTag("statusDot");
        top.addView(dot);

        statusBody = text("Flush can create a private nearby hotspot for you.", 14, MUTED, false);
        statusBody.setLineSpacing(0, 1.16f);
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sbp.topMargin = dp(8);
        card.addView(statusBody, sbp);

        startButton = button("Start Flush", true);
        startButton.setOnClickListener(v -> toggleSharing());
        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        startLp.topMargin = dp(15);
        card.addView(startButton, startLp);

        connectButton = button("Connect a device", false);
        connectButton.setOnClickListener(v -> showConnectionWizard());
        LinearLayout.LayoutParams connectLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        connectLp.topMargin = dp(9);
        card.addView(connectButton, connectLp);

        detailsButton = button("Connection details", false);
        detailsButton.setOnClickListener(v -> showConnectionDetails());
        LinearLayout.LayoutParams detailsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        detailsLp.topMargin = dp(7);
        card.addView(detailsButton, detailsLp);

        connectButton.setVisibility(View.GONE);
        detailsButton.setVisibility(View.GONE);
    }

    private void buildModeSwitch() {
        LinearLayout modeCard = card();
        modeCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        rootView.addView(modeCard, cardParams());

        LinearLayout segment = new LinearLayout(this);
        segment.setOrientation(LinearLayout.HORIZONTAL);
        segment.setPadding(dp(4), dp(4), dp(4), dp(4));
        segment.setBackground(rounded(Color.rgb(239,239,243), 15));
        modeCard.addView(segment);

        sendTab = segmentButton("Send", true);
        receiveTab = segmentButton("Receive", false);
        sendTab.setOnClickListener(v -> setMode(true));
        receiveTab.setOnClickListener(v -> setMode(false));
        segment.addView(sendTab, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams receiveLp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        receiveLp.leftMargin = dp(5);
        segment.addView(receiveTab, receiveLp);
    }

    private void buildSendCard() {
        sendCard = card();
        rootView.addView(sendCard, cardParams());

        sendCard.addView(text("SEND", 12, Color.rgb(139,139,148), true));
        TextView title = text("Choose what to share", 22, TEXT, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(4);
        sendCard.addView(title, tp);

        TextView desc = text("Pick once. Every connected device can receive the same files.", 14, MUTED, false);
        desc.setLineSpacing(0, 1.16f);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dpv.topMargin = dp(5);
        sendCard.addView(desc, dpv);

        Button choose = button("Choose files", true);
        choose.setOnClickListener(v -> pickFiles());
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        chooseLp.topMargin = dp(15);
        sendCard.addView(choose, chooseLp);

        selectedCount = text("0 files selected", 13, TEXT, true);
        selectedCount.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        scp.topMargin = dp(11);
        sendCard.addView(selectedCount, scp);

        broadcastInfo = text("Connect a device to start", 13, MUTED, false);
        broadcastInfo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bip.topMargin = dp(4);
        sendCard.addView(broadcastInfo, bip);

        Button clear = button("Clear selection", false);
        clear.setOnClickListener(v -> {
            SharedFileStore.clear();
            refreshUi();
        });
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        clearLp.topMargin = dp(10);
        sendCard.addView(clear, clearLp);
    }

    private void buildReceiveCard() {
        receiveCard = card();
        receiveCard.setVisibility(View.GONE);
        rootView.addView(receiveCard, cardParams());

        receiveCard.addView(text("RECEIVE", 12, Color.rgb(139,139,148), true));
        TextView title = text("Ready for incoming files", 22, TEXT, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(4);
        receiveCard.addView(title, tp);

        TextView desc = text("Files from iPhone are saved automatically to Downloads/Flush. Progress appears here only while something is happening.", 14, MUTED, false);
        desc.setLineSpacing(0, 1.16f);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dpv.topMargin = dp(5);
        receiveCard.addView(desc, dpv);

        recentIncoming = new LinearLayout(this);
        recentIncoming.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams recentLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        recentLp.topMargin = dp(10);
        receiveCard.addView(recentIncoming, recentLp);
    }

    private void buildActivityCard() {
        activityCard = card();
        rootView.addView(activityCard, cardParams());
        activityCard.addView(text("ACTIVE TRANSFERS", 12, Color.rgb(139,139,148), true));

        transferList = new LinearLayout(this);
        transferList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(3);
        activityCard.addView(transferList, tlp);
        activityCard.setVisibility(View.GONE);
    }

    private void playIntroAnimation() {
        rootView.setAlpha(0f);
        rootView.setTranslationY(dp(14));
        rootView.animate().alpha(1f).translationY(0f).setDuration(420).start();

        brandMark.setScaleX(0.35f);
        brandMark.setScaleY(0.35f);
        brandMark.setRotation(-12f);
        brandMark.animate()
                .scaleX(1f)
                .scaleY(1f)
                .rotation(0f)
                .setDuration(620)
                .setInterpolator(new OvershootInterpolator(1.45f))
                .start();

        brandText.setAlpha(0f);
        brandText.setTranslationX(-dp(12));
        brandText.animate().alpha(1f).translationX(0f).setStartDelay(120).setDuration(380).start();
    }

    private void showHotspotPrompt() {
        boolean existingDetected = LocalHttpServer.hasLikelyHotspotInterface();
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(existingDetected ? "Ready to start Flush" : "Turn on nearby sharing")
                .setMessage(existingDetected
                        ? "A hotspot appears to be active. Flush can use it, or create a temporary private hotspot of its own."
                        : "Flush can create a temporary private hotspot automatically. The other phone only needs Wi‑Fi turned on.")
                .setNegativeButton("Not now", null);

        if (existingDetected) {
            builder.setPositiveButton("Use current hotspot", (d, w) -> startWithExistingHotspot())
                    .setNeutralButton("Create Flush hotspot", (d, w) -> beginManagedSharing());
        } else {
            builder.setPositiveButton("Start Flush", (d, w) -> beginManagedSharing());
        }
        builder.show();
    }

    private void toggleSharing() {
        if (TransferService.isRunning()) {
            Intent stop = new Intent(this, TransferService.class);
            stop.setAction(TransferService.ACTION_STOP);
            startService(stop);
            HotspotController.stop();
            existingHotspotMode = false;
            handler.postDelayed(this::refreshUi, 300);
            return;
        }

        if (LocalHttpServer.hasLikelyHotspotInterface()) {
            new AlertDialog.Builder(this)
                    .setTitle("How should Flush connect?")
                    .setMessage("Use the hotspot already running, or let Flush create a temporary private hotspot with its own scannable password.")
                    .setPositiveButton("Use current hotspot", (d, w) -> startWithExistingHotspot())
                    .setNeutralButton("Create Flush hotspot", (d, w) -> beginManagedSharing())
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            beginManagedSharing();
        }
    }

    private void beginManagedSharing() {
        if (!hasWifiPermission()) {
            pendingStartAfterPermission = true;
            requestWifiPermission();
            return;
        }

        existingHotspotMode = false;
        statusTitle.setText("Starting Flush…");
        statusTitle.setTextColor(RED);
        statusBody.setText("Creating a private nearby Wi‑Fi network.");
        startButton.setEnabled(false);

        HotspotController.start(this, new HotspotController.Callback() {
            @Override
            public void onStarted(String ssid, String passphrase) {
                runOnUiThread(() -> {
                    startTransferService();
                    startButton.setEnabled(true);
                    handler.postDelayed(MainActivity.this::refreshUi, 450);
                    handler.postDelayed(MainActivity.this::refreshUi, 1100);
                });
            }

            @Override
            public void onFailed(int reason) {
                runOnUiThread(() -> {
                    startButton.setEnabled(true);
                    showHotspotFailure(reason);
                });
            }

            @Override
            public void onStopped() {
                runOnUiThread(() -> {
                    if (TransferService.isRunning() && !existingHotspotMode) {
                        Intent stop = new Intent(MainActivity.this, TransferService.class);
                        stop.setAction(TransferService.ACTION_STOP);
                        startService(stop);
                    }
                    refreshUi();
                });
            }
        });
    }

    private void showHotspotFailure(int reason) {
        String extra = reason == WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE
                ? " Your normal hotspot may already be active."
                : "";
        new AlertDialog.Builder(this)
                .setTitle("Couldn’t create the Flush hotspot")
                .setMessage("Android did not allow Flush to create its temporary hotspot." + extra)
                .setPositiveButton("Use current hotspot", (d, w) -> startWithExistingHotspot())
                .setNeutralButton("Hotspot settings", (d, w) -> openHotspotSettings())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startWithExistingHotspot() {
        existingHotspotMode = true;
        HotspotController.stop();
        startTransferService();
        handler.postDelayed(this::refreshUi, 500);
        handler.postDelayed(() -> {
            if (TransferService.getShareUrl() == null) {
                new AlertDialog.Builder(this)
                        .setTitle("Turn on your hotspot")
                        .setMessage("Flush cannot see a hotspot address yet. Turn on Personal Hotspot, then return to Flush.")
                        .setPositiveButton("Open hotspot settings", (d, w) -> openHotspotSettings())
                        .setNegativeButton("I’ll do it", null)
                        .show();
            }
        }, 1200);
    }

    private void startTransferService() {
        ensureNotificationPermission();
        Intent start = new Intent(this, TransferService.class);
        start.setAction(TransferService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(start);
        else startService(start);
    }

    private boolean hasWifiPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestWifiPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, REQUEST_NEARBY_WIFI);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_NEARBY_WIFI);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NEARBY_WIFI) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && pendingStartAfterPermission) {
                pendingStartAfterPermission = false;
                beginManagedSharing();
            } else if (!granted) {
                pendingStartAfterPermission = false;
                new AlertDialog.Builder(this)
                        .setTitle("Nearby Wi‑Fi permission needed")
                        .setMessage("Flush needs Nearby Wi‑Fi permission to create its temporary local hotspot. You can still use your normal hotspot instead.")
                        .setPositiveButton("Use current hotspot", (d, w) -> startWithExistingHotspot())
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        }
    }

    private void showConnectionWizard() {
        if (!TransferService.isRunning()) {
            Toast.makeText(this, "Start Flush first", Toast.LENGTH_SHORT).show();
            return;
        }

        final int[] step = {0};

        ScrollView scroll = new ScrollView(this);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(22), dp(10), dp(22), dp(12));
        scroll.addView(wrap);

        TextView stepLabel = text("STEP 1 OF 2", 12, RED, true);
        wrap.addView(stepLabel);

        TextView title = text("Connect to Flush Wi‑Fi", 22, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = dp(7);
        wrap.addView(title, titleLp);

        TextView body = text("Turn on Wi‑Fi on the other phone, then scan this code.", 14, MUTED, false);
        body.setLineSpacing(0, 1.16f);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bodyLp.topMargin = dp(6);
        wrap.addView(body, bodyLp);

        ImageView qr = new ImageView(this);
        qr.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        qr.setBackground(rounded(Color.WHITE, 16));
        qr.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams qrLp = new LinearLayout.LayoutParams(dp(230), dp(230));
        qrLp.gravity = Gravity.CENTER_HORIZONTAL;
        qrLp.topMargin = dp(14);
        wrap.addView(qr, qrLp);

        TextView helper = text("", 13, MUTED, false);
        helper.setGravity(Gravity.CENTER);
        helper.setTextIsSelectable(true);
        LinearLayout.LayoutParams helperLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        helperLp.topMargin = dp(8);
        wrap.addView(helper, helperLp);

        Runnable render = () -> {
            if (step[0] == 0) {
                stepLabel.setText("STEP 1 OF 2");
                title.setText("Connect to Flush Wi‑Fi");
                if (HotspotController.isActive() && !existingHotspotMode) {
                    body.setText("On iPhone or Android, turn on Wi‑Fi and scan this code to join the temporary Flush network.");
                    String wifiPayload = HotspotController.getWifiQrPayload();
                    qr.setVisibility(View.VISIBLE);
                    qr.setImageBitmap(wifiPayload == null ? null : makeQr(wifiPayload, 720));
                    String ssid = HotspotController.getSsid();
                    helper.setText("Network: " + (ssid == null ? "Flush" : ssid));
                } else {
                    body.setText("Connect the other phone to your existing Android hotspot. Then tap Next.");
                    qr.setVisibility(View.GONE);
                    helper.setText("Use the hotspot name and password shown in Android Hotspot Settings.");
                }
            } else {
                stepLabel.setText("STEP 2 OF 2");
                title.setText("Open Flush");
                body.setText("Once the other phone is connected to Wi‑Fi, scan this code to open the Flush sharing page.");
                currentUrl = TransferService.getShareUrl();
                qr.setVisibility(View.VISIBLE);
                qr.setImageBitmap(currentUrl == null ? null : makeQr(currentUrl, 720));
                helper.setText(currentUrl == null ? "Preparing the local link…" : "Ready to open Flush");
            }
        };

        render.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Connect a device")
                .setView(scroll)
                .setNegativeButton("Close", null)
                .setPositiveButton("Next", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setOnClickListener(v -> {
                if (step[0] == 0) {
                    step[0] = 1;
                    render.run();
                    positive.setText("Done");
                } else {
                    dialog.dismiss();
                }
            });
        });
        dialog.show();
    }

    private void showConnectionDetails() {
        if (!TransferService.isRunning()) {
            Toast.makeText(this, "Start Flush first", Toast.LENGTH_SHORT).show();
            return;
        }

        currentUrl = TransferService.getShareUrl();
        String pin = TransferService.getSessionPin();
        StringBuilder message = new StringBuilder();

        if (HotspotController.isActive() && !existingHotspotMode) {
            message.append("Network: ").append(HotspotController.getSsid() == null ? "Flush" : HotspotController.getSsid()).append("\n");
            String pass = HotspotController.getPassphrase();
            message.append("Password: ").append(pass == null || pass.isEmpty() ? "No password" : pass).append("\n\n");
        } else {
            message.append("Network: your existing Android hotspot\n\n");
        }

        message.append("Session PIN: ").append(pin == null ? "—" : pin).append("\n");
        message.append("Local link: ").append(currentUrl == null ? "Preparing…" : currentUrl);

        new AlertDialog.Builder(this)
                .setTitle("Connection details")
                .setMessage(message.toString())
                .setPositiveButton("Copy link", (d, w) -> copyCurrentUrl())
                .setNeutralButton("Hotspot settings", (d, w) -> openHotspotSettings())
                .setNegativeButton("Close", null)
                .show();
    }

    private void openHotspotSettings() {
        try {
            startActivity(new Intent("android.settings.TETHER_SETTINGS"));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void pickFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;

        int added = 0;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null) {
                    persistReadPermission(uri, data.getFlags());
                    SharedFileStore.add(this, uri);
                    added++;
                }
            }
        } else if (data.getData() != null) {
            Uri uri = data.getData();
            persistReadPermission(uri, data.getFlags());
            SharedFileStore.add(this, uri);
            added++;
        }

        if (added > 0) {
            Toast.makeText(this,
                    added + (added == 1 ? " file is ready to share" : " files are ready to share"),
                    Toast.LENGTH_SHORT).show();
        }
        refreshUi();
    }

    private void persistReadPermission(Uri uri, int flags) {
        int takeFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (Exception ignored) {}
    }

    private void setMode(boolean send) {
        sendMode = send;
        sendCard.setVisibility(send ? View.VISIBLE : View.GONE);
        receiveCard.setVisibility(send ? View.GONE : View.VISIBLE);
        styleSegmentButton(sendTab, send);
        styleSegmentButton(receiveTab, !send);
        refreshTransferViews();
    }

    private void refreshUi() {
        boolean running = TransferService.isRunning();
        int fileCount = SharedFileStore.count();
        int clients = TransferService.getConnectedClientCount();

        selectedCount.setText(fileCount + (fileCount == 1 ? " file selected" : " files selected"));
        broadcastInfo.setText(clients > 0
                ? "Ready for " + clients + (clients == 1 ? " connected device" : " connected devices")
                : "Connect a device to start");

        refreshTransferViews();
        showTransferSignals();

        TextView dot = findStatusDot();

        if (!running) {
            boolean existingDetected = LocalHttpServer.hasLikelyHotspotInterface();
            statusTitle.setText(HotspotController.isStarting()
                    ? "Starting Flush…"
                    : (existingDetected ? "Hotspot detected" : "Flush is off"));
            statusTitle.setTextColor(HotspotController.isStarting() ? RED : TEXT);
            clientsText.setText("Not connected");
            statusBody.setText(HotspotController.isStarting()
                    ? "Creating a private nearby network."
                    : (existingDetected
                    ? "Tap Start Flush and choose whether to use the current hotspot or create a temporary Flush hotspot."
                    : "Start Flush to create a nearby sharing connection."));
            startButton.setText(HotspotController.isStarting() ? "Starting…" : "Start Flush");
            startButton.setEnabled(!HotspotController.isStarting());
            connectButton.setVisibility(View.GONE);
            detailsButton.setVisibility(View.GONE);
            if (dot != null) dot.setTextColor(HotspotController.isStarting() ? RED : Color.rgb(190,190,196));
            currentUrl = null;
            return;
        }

        startButton.setEnabled(true);
        startButton.setText("Stop Flush");
        connectButton.setVisibility(View.VISIBLE);
        detailsButton.setVisibility(View.VISIBLE);

        currentUrl = TransferService.getShareUrl();

        if (currentUrl == null) {
            statusTitle.setText("Preparing connection…");
            statusTitle.setTextColor(RED);
            clientsText.setText("Local address not ready");
            statusBody.setText("The hotspot is active. Flush is preparing the local sharing link.");
            if (dot != null) dot.setTextColor(RED);
            return;
        }

        statusTitle.setText(clients > 0 ? "Ready" : "Waiting for a device");
        statusTitle.setTextColor(GREEN);
        clientsText.setText(clients == 0
                ? "No devices connected"
                : clients + (clients == 1 ? " device connected" : " devices connected"));
        statusBody.setText(clients > 0
                ? "Sharing is active. Send or receive whenever you’re ready."
                : "Tap Connect a device for the simple two-step setup.");
        if (dot != null) dot.setTextColor(GREEN);
    }

    private TextView findStatusDot() {
        View found = findViewWithTag(rootView, "statusDot");
        return found instanceof TextView ? (TextView) found : null;
    }

    private View findViewWithTag(View view, Object tag) {
        if (tag.equals(view.getTag())) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                View found = findViewWithTag(group.getChildAt(i), tag);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void showTransferSignals() {
        TransferTracker.Snapshot active = TransferTracker.latestActive();
        if (active != null && !active.id.equals(lastActiveTransferId)) {
            lastActiveTransferId = active.id;
            String verb = active.direction == TransferTracker.Direction.INCOMING ? "Receiving " : "Sending ";
            Toast.makeText(this, verb + active.name, Toast.LENGTH_SHORT).show();
        }

        TransferTracker.Snapshot latest = TransferTracker.latest();
        if (latest != null && latest.state == TransferTracker.State.COMPLETE && !latest.id.equals(lastCompletedTransferId)) {
            lastCompletedTransferId = latest.id;
            String verb = latest.direction == TransferTracker.Direction.INCOMING ? "Received " : "Sent ";
            Toast.makeText(this, verb + latest.name + " ✓", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshTransferViews() {
        List<TransferTracker.Snapshot> transfers = TransferTracker.snapshot();
        transferList.removeAllViews();
        recentIncoming.removeAllViews();

        int activeShown = 0;
        int incomingShown = 0;
        boolean hasActive = false;

        for (TransferTracker.Snapshot snapshot : transfers) {
            if (snapshot.state == TransferTracker.State.ACTIVE && activeShown < 4) {
                transferList.addView(transferRow(snapshot));
                activeShown++;
                hasActive = true;
            }

            if (snapshot.direction == TransferTracker.Direction.INCOMING && incomingShown < 4) {
                recentIncoming.addView(transferRow(snapshot));
                incomingShown++;
            }
        }

        activityCard.setVisibility(hasActive ? View.VISIBLE : View.GONE);

        if (incomingShown == 0) {
            recentIncoming.addView(emptyLine("Waiting for files…"));
        }
    }

    private View transferRow(TransferTracker.Snapshot snapshot) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(9), 0, dp(9));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        wrap.addView(top);

        String arrow = snapshot.direction == TransferTracker.Direction.INCOMING ? "↓" : "↑";
        TextView icon = text(arrow, 22,
                snapshot.direction == TransferTracker.Direction.INCOMING ? GREEN : RED,
                true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(rounded(Color.rgb(249,246,247), 12));
        top.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout meta = new LinearLayout(this);
        meta.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        metaLp.leftMargin = dp(10);
        top.addView(meta, metaLp);

        TextView name = text(snapshot.name, 14, TEXT, true);
        name.setSingleLine(true);
        meta.addView(name);

        int pct = snapshot.percent();
        String state;
        if (snapshot.state == TransferTracker.State.ACTIVE) {
            state = pct >= 0 ? pct + "% · " + humanSize(snapshot.bytes) : humanSize(snapshot.bytes);
        } else if (snapshot.state == TransferTracker.State.COMPLETE) {
            state = "Complete ✓ · " + humanSize(snapshot.bytes);
        } else {
            state = "Transfer failed";
        }

        TextView detail = text(state, 12, snapshot.state == TransferTracker.State.FAILED ? RED : MUTED, false);
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailLp.topMargin = dp(3);
        meta.addView(detail, detailLp);

        if (snapshot.state == TransferTracker.State.ACTIVE) {
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setMax(100);
            if (pct >= 0) {
                progress.setIndeterminate(false);
                progress.setProgress(pct);
            } else {
                progress.setIndeterminate(true);
            }
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5));
            pp.topMargin = dp(7);
            wrap.addView(progress, pp);
        }

        return wrap;
    }

    private TextView emptyLine(String value) {
        TextView v = text(value, 13, MUTED, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(14), 0, dp(14));
        return v;
    }

    private Bitmap makeQr(String value, int size) {
        try {
            BitMatrix matrix = new QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, size, size);
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            int dark = Color.rgb(24,24,27);
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? dark : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException e) {
            return null;
        }
    }

    private void copyCurrentUrl() {
        if (currentUrl == null) {
            currentUrl = TransferService.getShareUrl();
        }
        if (currentUrl == null) {
            Toast.makeText(this, "The local link is not ready yet", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Flush link", currentUrl));
            Toast.makeText(this, "Flush link copied", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(rounded(Color.WHITE, 22));
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        return lp;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String label, boolean filled) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(14), 0, dp(14), 0);
        if (filled) {
            b.setTextColor(Color.WHITE);
            b.setBackground(rounded(RED, 14));
        } else {
            b.setTextColor(RED);
            GradientDrawable bg = rounded(Color.rgb(255, 245, 247), 14);
            bg.setStroke(dp(1), Color.rgb(241, 190, 198));
            b.setBackground(bg);
        }
        return b;
    }

    private Button segmentButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        styleSegmentButton(b, active);
        return b;
    }

    private void styleSegmentButton(Button b, boolean active) {
        b.setTextColor(active ? RED : MUTED);
        b.setBackground(rounded(active ? Color.WHITE : Color.TRANSPARENT, 12));
        b.setElevation(active ? dp(1) : 0);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private String humanSize(long n) {
        if (n < 0) return "size unavailable";
        double value = n;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int i = 0;
        while (value >= 1024 && i < units.length - 1) {
            value /= 1024;
            i++;
        }
        if (i == 0) return ((long)value) + " " + units[i];
        return String.format(Locale.US, "%.1f %s", value, units[i]);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
