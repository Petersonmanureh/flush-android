package com.pmviewtech.flush;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public final class SharedFileStore {
    public static final class Entry {
        public final int id;
        public final Uri uri;
        public final String name;
        public final String mime;
        public final long size;

        Entry(int id, Uri uri, String name, String mime, long size) {
            this.id = id;
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.size = size;
        }
    }

    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);
    private static final Map<Integer, Entry> FILES = Collections.synchronizedMap(new LinkedHashMap<>());

    private SharedFileStore() {}

    public static Entry add(Context context, Uri uri) {
        ContentResolver resolver = context.getContentResolver();
        String name = "file";
        long size = -1L;
        String mime = resolver.getType(uri);
        if (mime == null || mime.trim().isEmpty()) mime = "application/octet-stream";

        Cursor cursor = null;
        try {
            cursor = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }

        int id = NEXT_ID.getAndIncrement();
        Entry entry = new Entry(id, uri, name, mime, size);
        FILES.put(id, entry);
        return entry;
    }

    public static Entry get(int id) {
        return FILES.get(id);
    }

    public static List<Entry> snapshot() {
        synchronized (FILES) {
            return new ArrayList<>(FILES.values());
        }
    }

    public static int count() {
        return FILES.size();
    }

    public static void remove(int id) {
        FILES.remove(id);
    }

    public static void clear() {
        FILES.clear();
    }
}
