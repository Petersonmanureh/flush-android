package com.pmviewtech.flush;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalHttpServer extends Thread {
    private final Context context;
    private final int port;
    private final String pin;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running = true;
    private volatile ServerSocket serverSocket;

    public LocalHttpServer(Context context, int port, String pin) {
        super("FlushLocalServer");
        this.context = context.getApplicationContext();
        this.port = port;
        this.pin = pin;
    }

    @Override
    public void run() {
        try (ServerSocket ss = new ServerSocket(port)) {
            serverSocket = ss;
            ss.setReuseAddress(true);
            while (running) {
                try {
                    Socket socket = ss.accept();
                    socket.setSoTimeout(120000);
                    pool.execute(() -> handle(socket));
                } catch (IOException e) {
                    if (running) e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            running = false;
            pool.shutdownNow();
        }
    }

    public void shutdown() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {}
        pool.shutdownNow();
    }

    private void handle(Socket socket) {
        try (Socket s = socket;
             InputStream rawIn = new BufferedInputStream(s.getInputStream(), 64 * 1024);
             OutputStream out = new BufferedOutputStream(s.getOutputStream(), 64 * 1024)) {

            String requestLine = readLine(rawIn);
            if (requestLine == null || requestLine.isEmpty()) return;
            String[] first = requestLine.split(" ", 3);
            if (first.length < 2) {
                sendText(out, 400, "Bad Request", "text/plain; charset=utf-8", "Bad request");
                return;
            }

            String method = first[0].toUpperCase(Locale.US);
            String target = first[1];
            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = readLine(rawIn)) != null && !line.isEmpty()) {
                int p = line.indexOf(':');
                if (p > 0) {
                    headers.put(line.substring(0, p).trim().toLowerCase(Locale.US), line.substring(p + 1).trim());
                }
            }

            int q = target.indexOf('?');
            String path = q >= 0 ? target.substring(0, q) : target;
            String query = q >= 0 ? target.substring(q + 1) : "";
            Map<String, String> params = parseQuery(query);

            if ("GET".equals(method) && "/".equals(path)) {
                if (!pin.equals(params.get("pin"))) {
                    sendText(out, 200, "OK", "text/html; charset=utf-8", loginHtml());
                } else {
                    sendText(out, 200, "OK", "text/html; charset=utf-8", homeHtml());
                }
                return;
            }

            if (!pin.equals(params.get("pin"))) {
                sendText(out, 403, "Forbidden", "text/plain; charset=utf-8", "Invalid session PIN");
                return;
            }

            if ("GET".equals(method) && "/download".equals(path)) {
                int id = parseInt(params.get("id"), -1);
                SharedFileStore.Entry entry = SharedFileStore.get(id);
                if (entry == null) {
                    sendText(out, 404, "Not Found", "text/plain; charset=utf-8", "File not found");
                    return;
                }
                streamSelectedFile(out, entry);
                return;
            }

            if ("POST".equals(method) && "/upload".equals(path)) {
                String name = cleanFileName(params.get("name"));
                String mime = params.get("type");
                if (mime == null || mime.trim().isEmpty()) mime = headers.get("content-type");
                if (mime == null || mime.trim().isEmpty()) mime = "application/octet-stream";

                long contentLength = parseLong(headers.get("content-length"), -1L);
                boolean chunked = "chunked".equalsIgnoreCase(headers.get("transfer-encoding"));

                if (name == null || name.isEmpty()) {
                    sendText(out, 400, "Bad Request", "application/json; charset=utf-8", "{\"ok\":false,\"error\":\"Missing filename\"}");
                    return;
                }
                if (contentLength < 0 && !chunked) {
                    sendText(out, 411, "Length Required", "application/json; charset=utf-8", "{\"ok\":false,\"error\":\"Upload length required\"}");
                    return;
                }

                try {
                    saveIncoming(name, mime, rawIn, contentLength, chunked);
                    sendText(out, 200, "OK", "application/json; charset=utf-8", "{\"ok\":true}");
                } catch (Exception e) {
                    e.printStackTrace();
                    sendText(out, 500, "Server Error", "application/json; charset=utf-8", "{\"ok\":false,\"error\":\"Save failed\"}");
                }
                return;
            }

            if ("GET".equals(method) && "/ping".equals(path)) {
                sendText(out, 200, "OK", "application/json; charset=utf-8", "{\"ok\":true}");
                return;
            }

            sendText(out, 404, "Not Found", "text/plain; charset=utf-8", "Not found");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void streamSelectedFile(OutputStream out, SharedFileStore.Entry entry) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        InputStream input = resolver.openInputStream(entry.uri);
        if (input == null) throw new FileNotFoundException(entry.name);

        String ascii = entry.name.replaceAll("[^A-Za-z0-9._ -]", "_").replace("\"", "_");
        String encoded = URLEncoder.encode(entry.name, StandardCharsets.UTF_8.name()).replace("+", "%20");

        write(out, "HTTP/1.1 200 OK\r\n");
        write(out, "Content-Type: " + entry.mime + "\r\n");
        if (entry.size >= 0) write(out, "Content-Length: " + entry.size + "\r\n");
        write(out, "Content-Disposition: attachment; filename=\"" + ascii + "\"; filename*=UTF-8''" + encoded + "\r\n");
        write(out, "Cache-Control: no-store\r\n");
        write(out, "Connection: close\r\n\r\n");

        try (InputStream in = new BufferedInputStream(input, 64 * 1024)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
        }
    }

    private void saveIncoming(String name, String mime, InputStream in, long contentLength, boolean chunked) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, name);
        values.put(MediaStore.Downloads.MIME_TYPE, mime);
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Flush");
        values.put(MediaStore.Downloads.IS_PENDING, 1);

        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("Could not create download");

        boolean ok = false;
        try (OutputStream output = resolver.openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("Could not open destination");
            if (chunked) {
                copyChunked(in, output);
            } else if (contentLength >= 0) {
                copyFixed(in, output, contentLength);
            } else {
                copyUntilEof(in, output);
            }
            output.flush();
            ok = true;
        } finally {
            if (ok) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
            } else {
                resolver.delete(uri, null, null);
            }
        }
    }

    private static void copyFixed(InputStream in, OutputStream out, long remaining) throws IOException {
        byte[] buf = new byte[64 * 1024];
        while (remaining > 0) {
            int want = (int)Math.min(buf.length, remaining);
            int n = in.read(buf, 0, want);
            if (n < 0) throw new IOException("Unexpected end of upload");
            out.write(buf, 0, n);
            remaining -= n;
        }
    }

    private static void copyUntilEof(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }

    private static void copyChunked(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        while (true) {
            String sizeLine = readLine(in);
            if (sizeLine == null) throw new IOException("Bad chunked upload");
            int semicolon = sizeLine.indexOf(';');
            if (semicolon >= 0) sizeLine = sizeLine.substring(0, semicolon);
            int size = Integer.parseInt(sizeLine.trim(), 16);
            if (size == 0) {
                while (true) {
                    String trailer = readLine(in);
                    if (trailer == null || trailer.isEmpty()) break;
                }
                return;
            }
            int remaining = size;
            while (remaining > 0) {
                int n = in.read(buf, 0, Math.min(buf.length, remaining));
                if (n < 0) throw new IOException("Unexpected end of chunk");
                out.write(buf, 0, n);
                remaining -= n;
            }
            String end = readLine(in);
            if (end == null) throw new IOException("Bad chunk ending");
        }
    }

    private String homeHtml() throws IOException {
        String template = readAsset("index.html");
        StringBuilder files = new StringBuilder();
        List<SharedFileStore.Entry> snapshot = SharedFileStore.snapshot();
        if (snapshot.isEmpty()) {
            files.append("<div class=\"empty\">No Android files selected yet. Choose files in the Flush app.</div>");
        } else {
            for (SharedFileStore.Entry e : snapshot) {
                files.append("<a class=\"fileRow\" href=\"/download?pin=")
                        .append(url(pin)).append("&id=").append(e.id).append("\">")
                        .append("<div><strong>").append(html(e.name)).append("</strong><span>")
                        .append(html(humanSize(e.size))).append("</span></div>")
                        .append("<b>Download</b></a>");
            }
        }
        return template.replace("{{PIN}}", js(pin)).replace("{{FILES}}", files.toString());
    }

    private String loginHtml() {
        return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
                "<title>Flush</title><style>body{margin:0;background:#f8f8fa;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:#17171b}" +
                ".wrap{max-width:520px;margin:auto;padding:28px 18px}.brand{font-size:38px;font-weight:900;color:#c91424;margin:40px 0 6px}.sub{color:#777;margin-bottom:28px}" +
                ".card{background:white;padding:22px;border-radius:22px;box-shadow:0 10px 35px #00000012}input{width:100%;box-sizing:border-box;padding:15px;border:1px solid #ddd;border-radius:13px;font-size:18px}" +
                "button{margin-top:12px;width:100%;padding:15px;border:0;border-radius:13px;background:#c91424;color:white;font-weight:800;font-size:16px}</style></head>" +
                "<body><div class=\"wrap\"><div class=\"brand\">flush.</div><div class=\"sub\">Private nearby file transfer</div><div class=\"card\"><h2>Enter session PIN</h2>" +
                "<form><input name=\"pin\" inputmode=\"numeric\" pattern=\"[0-9]*\" maxlength=\"6\" placeholder=\"6-digit PIN\" autofocus><button>Connect</button></form></div></div></body></html>";
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = context.getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static void sendText(OutputStream out, int code, String reason, String type, String body) throws IOException {
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        write(out, "HTTP/1.1 " + code + " " + reason + "\r\n");
        write(out, "Content-Type: " + type + "\r\n");
        write(out, "Content-Length: " + data.length + "\r\n");
        write(out, "Cache-Control: no-store\r\n");
        write(out, "Connection: close\r\n\r\n");
        out.write(data);
        out.flush();
    }

    private static void write(OutputStream out, String s) throws IOException {
        out.write(s.getBytes(StandardCharsets.ISO_8859_1));
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int prev = -1;
        int c;
        while ((c = in.read()) != -1) {
            if (prev == '\r' && c == '\n') {
                byte[] b = out.toByteArray();
                int len = b.length;
                if (len > 0 && b[len - 1] == '\r') len--;
                return new String(b, 0, len, StandardCharsets.ISO_8859_1);
            }
            out.write(c);
            prev = c;
            if (out.size() > 64 * 1024) throw new IOException("Header line too long");
        }
        if (out.size() == 0) return null;
        return out.toString(StandardCharsets.ISO_8859_1.name());
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String pair : query.split("&")) {
            int p = pair.indexOf('=');
            String key = p >= 0 ? pair.substring(0, p) : pair;
            String val = p >= 0 ? pair.substring(p + 1) : "";
            try {
                map.put(URLDecoder.decode(key, "UTF-8"), URLDecoder.decode(val, "UTF-8"));
            } catch (Exception ignored) {}
        }
        return map;
    }

    private static String cleanFileName(String name) {
        if (name == null) return null;
        name = name.replace("\\", "_").replace("/", "_").replace("\r", "").replace("\n", "").trim();
        if (name.length() > 180) name = name.substring(name.length() - 180);
        return name;
    }

    public static String findBestLocalIp() {
        class Candidate {
            final String iface;
            final String ip;
            final int score;
            Candidate(String iface, String ip, int score) { this.iface = iface; this.ip = ip; this.score = score; }
        }
        List<Candidate> candidates = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return null;
            for (NetworkInterface ni : Collections.list(interfaces)) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName().toLowerCase(Locale.US);
                for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (!(addr instanceof Inet4Address) || addr.isLoopbackAddress()) continue;
                    String ip = addr.getHostAddress();
                    if (!isPrivate(ip)) continue;
                    int score = 0;
                    if (n.contains("ap") || n.contains("softap") || n.contains("swlan")) score += 100;
                    if (n.contains("wlan") || n.contains("wifi")) score += 60;
                    if (n.contains("rndis")) score += 40;
                    if (ip.startsWith("192.168.43.")) score += 30;
                    if (ip.startsWith("192.168.")) score += 20;
                    if (ip.startsWith("172.")) score += 10;
                    candidates.add(new Candidate(n, ip, score));
                }
            }
        } catch (Exception ignored) {}
        if (candidates.isEmpty()) return null;
        candidates.sort((a, b) -> Integer.compare(b.score, a.score));
        return candidates.get(0).ip;
    }

    public static List<String> findAllLocalIps() {
        List<String> ips = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return ips;
            for (NetworkInterface ni : Collections.list(interfaces)) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress() && isPrivate(addr.getHostAddress())) {
                        ips.add(addr.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) {}
        ips.sort(Comparator.naturalOrder());
        return ips;
    }

    private static boolean isPrivate(String ip) {
        return ip.startsWith("10.") || ip.startsWith("192.168.") ||
                ip.matches("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*");
    }

    private static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s); } catch (Exception e) { return fallback; }
    }

    private static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s); } catch (Exception e) { return fallback; }
    }

    private static String humanSize(long n) {
        if (n < 0) return "Size unavailable";
        double value = n;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int i = 0;
        while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
        if (i == 0) return ((long)value) + " " + units[i];
        return String.format(Locale.US, "%.1f %s", value, units[i]);
    }

    private static String html(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String js(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "\\n");
    }

    private static String url(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }
}
