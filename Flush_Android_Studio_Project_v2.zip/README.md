# Flush

**Flush** is a simple Android-to-iPhone nearby file transfer app. The Android phone hosts a temporary private web page over its hotspot, and the iPhone opens that page in Safari.

## User experience

1. Open **Flush** on Android.
2. Tap **Open Hotspot Settings** and turn on the Android hotspot.
3. Return to Flush and tap **Start Sharing**.
4. Flush displays a QR code, local link and 6-digit session PIN.
5. Connect the iPhone to the Android hotspot.
6. Scan the QR code with the iPhone camera.
7. Use the web page to transfer files both ways.

### iPhone → Android

The iPhone selects one or more files in Safari. Flush saves received files directly to:

`Downloads/Flush`

### Android → iPhone

Tap **Choose Android Files** in the app. Only those selected files are exposed on the iPhone transfer page for that sharing session.

## Privacy and networking

The nearby-transfer mode does **not require a public domain or cloud server**. The file data travels directly over the local hotspot/Wi-Fi network. A random 6-digit PIN is generated every time sharing starts.

A future hosted relay mode can be added later if you want Flush to send files between devices that are not on the same network. That would require a domain, HTTPS, server-side storage/relay rules and expiry/security controls. It is intentionally not enabled in v1 because the requested Android-hotspot-to-iPhone workflow works better without uploading files to the internet.

## Android requirements

- Android 10 (API 29) or newer.
- iPhone only needs Safari / Camera; no iPhone app is required.
- The Android hotspot must allow connected devices to reach the hotspot host. Most normal Android hotspots do.

## Build the APK with GitHub Actions

This project already contains `.github/workflows/build-apk.yml`.

1. Put the project in a GitHub repository.
2. Push to the `main` branch, or open **Actions → Build Flush APK → Run workflow**.
3. When the workflow finishes, download the artifact named **Flush-APK**.
4. It contains `Flush-v1.0.0.apk`, which can be installed directly on Android after allowing installation from that source.

The generated APK is a **debug-signed installable build**, suitable for direct testing. Before Google Play release, create a private production signing key and build a signed release/AAB.

## Project identity

- App name: **Flush**
- Package: `com.pmviewtech.flush`
- Version: `1.0.0`
- Minimum Android: API 29
- Target Android: API 35
- Theme: red / white / charcoal
- QR library: ZXing Core 3.5.3

## Main components

- `MainActivity.java` — red native Android interface, hotspot shortcut, file picker, QR and sharing controls.
- `TransferService.java` — foreground service that keeps sharing active.
- `LocalHttpServer.java` — built-in local HTTP file transfer server.
- `SharedFileStore.java` — tracks Android files selected for sharing.
- `assets/index.html` — responsive iPhone transfer interface.

## Security notes

- Stop sharing when finished.
- Only use hotspots/networks you control.
- Nearby mode uses local HTTP because traffic stays inside the local hotspot. The session PIN prevents casual access by another connected device.
- For a future internet/relay mode, HTTPS would be mandatory.
