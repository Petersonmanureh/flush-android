# Flush 2.1

Flush is an Android-hosted nearby file transfer app designed for Android ↔ iPhone and Android ↔ browser sharing without Termux, cloud storage, or mobile data.

## Main experience

- One-tap temporary local hotspot using Android's Local Only Hotspot API.
- Clean Android home screen with Send / Receive directly below connection status.
- Guided Connect a Device wizard: Wi-Fi QR first, Open Flush QR second—never both on-screen together.
- Connection details (PIN, URL, Wi-Fi password/settings) are hidden from the main screen.
- Send / Receive mode on Android and browser.
- Multiple connected iPhones can receive the same shared Android file.
- Live transfer percentages and notifications.
- iPhone media preview grid with per-file upload progress.
- Incoming iPhone files save to `Downloads/Flush` on Android.

## Android requirements

- minSdk 29
- targetSdk 35
- Java 17 build environment
- Nearby Wi-Fi permission on Android 13+

## Build

From the project root:

```bash
gradle assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Testing update note

GitHub-hosted debug builds may use a different debug signing key between build runners. If Android reports that the new APK cannot update the existing test installation, uninstall the older Flush test build and install the new APK. Production releases should use a stable private signing key stored outside the public repository (for example via GitHub Secrets / Play App Signing).
